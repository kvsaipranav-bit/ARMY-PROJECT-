# UGV Drone Detection System (UGV-DDS)

Autonomous Unmanned Ground Vehicle (UGV) surveillance system: detects and
tracks aerial drones using computer vision + thermal imaging, estimates
bearing toward the operator/mother-drone, and displays live threat and GPS
data on an operator console.

**Status: software scaffold / demo build.** It runs end-to-end (login →
live camera → detection pipeline → overlay → logging) on a stock/COCO YOLO
model out of the box. It is **not** a validated defense system — see
"What's real vs. placeholder" below before treating any output as
operationally trustworthy.

---

## 1. System architecture

```
                     ┌─────────────────────────┐
                     │   UGV Sensor Payload     │
                     │  (visible cam + thermal) │
                     └───────────┬─────────────┘
                                 │ frames
                     ┌───────────▼─────────────┐
                     │   Edge Compute (Jetson)  │
                     │  detection.py: YOLO      │
                     │  inference + bearing est.│
                     └───────────┬─────────────┘
                                 │ JSON detections (WS)
        ┌────────────────────────▼───────────────────────┐
        │              Backend (FastAPI, app.py)          │
        │  auth.py        — operator login (JWT)          │
        │  telemetry.py   — JSONL log + image snapshots   │
        │  /ws/detect     — live detection stream          │
        │  /api/*         — REST for login/telemetry/status│
        └────────────────────────┬───────────────────────┘
                                 │ HTTPS / WSS
                     ┌───────────▼─────────────┐
                     │  Operator Console (web)  │
                     │  login.html → dashboard  │
                     │  live overlay, threat    │
                     │  panel, compass, GPS,    │
                     │  telemetry log           │
                     └──────────────────────────┘
```

Data flow: camera → frame capture → (optional thermal fusion) → YOLO
inference → per-detection bearing estimate (pixel offset + camera FOV) →
rough operator-location projection (single-bearing line-of-bearing) →
threat scoring → pushed to console over WebSocket → logged to
`backend/data/telemetry/*.jsonl` + periodic JPEG snapshots in
`backend/data/images/`.

## 2. What's real vs. placeholder in this build

| Component | Status |
|---|---|
| Login, JWT sessions, console UI | Functional |
| Live browser camera capture → backend | Functional |
| YOLO inference pipeline (`ultralytics`) | Functional, **but** loaded with stock COCO weights unless you supply a drone-trained model — COCO has no "drone" class, so `airplane` / `bird` / `kite` are used as visible stand-ins for pipeline testing |
| Thermal fusion (`fuse_thermal`) | Functional alpha-blend; not sensor-calibrated — needs real thermal camera + extrinsic calibration |
| Bearing (direction) estimate | Functional single-frame pixel→angle math; accurate only if camera horizontal FOV is set correctly |
| Operator/mother-drone location estimate | **Rough placeholder.** A single bearing only gives a line, not a fix. Real triangulation needs 2+ bearings from different positions/times, or an RF direction-finding sensor on the control link |
| GPS | Uses the browser's `geolocation` API as a stand-in for a UGV-mounted GPS/GNSS module |
| Threat scoring | Simple heuristic (confidence + apparent size) — not validated against real threat criteria |
| Auth/user store | In-memory single-role table — replace with a real DB + RBAC before any real deployment |

## 3. Hardware requirements (recommended)

- **Compute:** NVIDIA Jetson Orin Nano/NX (on-UGV edge inference) or Jetson AGX Orin for heavier models
- **Visible camera:** Global-shutter USB3/CSI camera, ≥1080p, narrow-to-medium FOV lens for long-range detection
- **Thermal camera:** LWIR module (e.g. FLIR Boson/Lepton-class) for day/night detection
- **GPS/GNSS module:** u-blox NEO-M9N or similar, RTK if precision position is required
- **IMU/compass:** for accurate UGV heading (needed for the bearing math to mean anything in absolute terms)
- **Pan-tilt mount (optional):** to slew the camera toward a track and improve range/consistency
- **UGV chassis + drive electronics:** per mobility requirements (skid-steer/tracked recommended for rough terrain)
- **Comms:** Wi-Fi/mesh radio or tactical data link from UGV to operator console
- **Power:** sized for continuous compute + sensor + drive load; battery + power budget analysis needed

## 4. Software stack

- **Backend:** Python 3.10+, FastAPI, Uvicorn, WebSockets
- **CV/ML:** OpenCV, Ultralytics YOLO (v8), NumPy
- **Auth:** PyJWT + bcrypt
- **Frontend:** vanilla HTML/CSS/JS (no build step), browser `getUserMedia` + `geolocation` APIs
- **Data logging:** JSONL telemetry + JPEG snapshots on local disk (swap for a proper time-series DB — e.g. TimescaleDB/InfluxDB — for a fielded system)

## 5. Setup & run

```bash
# 1. Create a virtual environment
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set a real JWT secret (don't skip this)
export UGV_JWT_SECRET=$(openssl rand -hex 32)

# 4. (Optional but recommended) train or obtain drone-detection weights
#    and place them at backend/models/drone_yolo.pt — see section 6.
#    Without this, the app runs using COCO stand-in classes for demo purposes.

# 5. Run the backend (also serves the frontend)
cd backend
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

Open `http://localhost:8000` — default demo login is `operator1` /
`changeme123` (change this immediately: replace the bcrypt hash in
`backend/config.py` with your own — generate one with
`python -c "import bcrypt; print(bcrypt.hashpw(b'yourpassword', bcrypt.gensalt()).decode())"`).

Browsers only allow camera access on `localhost` or HTTPS — for access
from another device (e.g. a tablet mounted on the UGV console), put the
backend behind HTTPS (e.g. via a reverse proxy with a TLS cert, or a tool
like `mkcert` for local testing).

## 6. Model training (getting a real drone detector)

1. Collect/label a dataset of drones in visible + thermal imagery (public
   sets: "Drone-vs-Bird", "Anti-UAV", or your own captured footage).
2. Fine-tune YOLOv8 on that dataset:
   ```bash
   pip install ultralytics
   yolo detect train data=drone_dataset.yaml model=yolov8n.pt epochs=100 imgsz=640
   ```
3. Copy the resulting `best.pt` to `backend/models/drone_yolo.pt`.
4. Restart the backend — `detection.py` will automatically trust the
   model's own class names once it sees a class containing "drone"/"uas".

## 7. Implementation roadmap

- **Phase 1 — Software bring-up (this repo):** auth, live video pipeline,
  detection scaffold, telemetry logging, operator console. ✅
- **Phase 2 — Model development:** collect/label drone dataset (visible +
  thermal), train and validate YOLO model, benchmark accuracy/range/FPS
  on target compute (Jetson).
- **Phase 3 — Sensor integration:** wire in real thermal camera with
  calibrated visible/thermal fusion; integrate real GPS/IMU for UGV pose;
  replace browser geolocation stand-in.
- **Phase 4 — Direction-finding upgrade:** move from single-bearing
  projection to multi-bearing triangulation (multiple UGVs or a moving
  UGV taking bearings over time) or add RF direction-finding for the
  drone's control link.
- **Phase 5 — Field hardening:** persistent data store (replace JSONL),
  proper RBAC/user management, HTTPS/mesh comms, ruggedized enclosure,
  power budget validation, field testing against real UAS at range.
- **Phase 6 — Autonomy:** UGV path planning to reposition for a better
  bearing/track, optional pan-tilt camera slaving to active track.

## 8. Project structure

```
ugv-drone-detection/
├── backend/
│   ├── app.py            # FastAPI app: auth routes, /ws/detect, static serving
│   ├── auth.py            # JWT login/session handling
│   ├── config.py          # All tunables (weights path, thresholds, secrets)
│   ├── detection.py       # YOLO wrapper, bearing math, thermal fusion, location estimate
│   ├── telemetry.py       # JSONL logging + snapshot saving
│   ├── models/             # Put drone_yolo.pt here (not included)
│   └── data/
│       ├── images/         # Saved detection snapshots
│       ├── videos/         # (reserved for saved clips)
│       ├── telemetry/      # JSONL detection/threat logs
│       └── logs/           # (reserved for app logs)
├── frontend/
│   ├── login.html
│   ├── dashboard.html
│   ├── css/style.css
│   └── js/{login.js, dashboard.js}
├── requirements.txt
└── README.md
```

## 9. Security notes before any real use

- Replace `JWT_SECRET` and the demo password hash in `config.py`.
- Move the operator table to a real database with per-user bcrypt hashes.
- Restrict CORS (`allow_origins=["*"]` in `app.py`) to your actual frontend origin.
- Serve everything over HTTPS/WSS — camera access and secure cookies require it outside localhost.
- Add rate limiting to `/api/login`.
