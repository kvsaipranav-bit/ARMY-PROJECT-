"""
Detection pipeline: frame -> (optionally thermal-fused) -> YOLO inference
-> bounding boxes -> bearing estimate -> threat record.

NOTE on the model: stock YOLOv8/COCO weights do not include a "drone"
class. This module runs with COCO weights out of the box (using
DEMO_PROXY_CLASSES as a stand-in) so the full pipeline is testable
end-to-end. For real use, replace config.YOLO_WEIGHTS_PATH with a
model fine-tuned on a drone dataset (e.g. a labeled dataset of
quadcopters/fixed-wing UAS in visible + thermal imagery -- see
README "Model Training" section).
"""
import math
import time
from dataclasses import dataclass, field

import cv2
import numpy as np

import config

try:
    from ultralytics import YOLO
    _ULTRALYTICS_AVAILABLE = True
except ImportError:
    _ULTRALYTICS_AVAILABLE = False


@dataclass
class Detection:
    class_name: str
    confidence: float
    box: tuple  # x1, y1, x2, y2 (pixels)
    bearing_deg: float  # estimated horizontal bearing relative to UGV heading
    threat_level: str  # LOW / MEDIUM / HIGH
    timestamp: float = field(default_factory=time.time)


class DroneDetector:
    def __init__(self, weights_path: str = None):
        self.model = None
        self.classes_of_interest = set(config.DEMO_PROXY_CLASSES)
        if _ULTRALYTICS_AVAILABLE:
            try:
                self.model = YOLO(weights_path or config.YOLO_WEIGHTS_PATH)
                names = getattr(self.model, "names", {}) or {}
                # If a custom drone model is loaded, trust its own class names.
                if any("drone" in str(n).lower() or "uas" in str(n).lower() for n in names.values()):
                    self.classes_of_interest = {n for n in names.values()}
            except Exception as exc:  # weights missing on first run, etc.
                print(f"[detection] Could not load YOLO weights: {exc}")
                self.model = None
        else:
            print("[detection] ultralytics not installed -- running in stub mode. "
                  "pip install ultralytics to enable real inference.")

    @property
    def is_ready(self) -> bool:
        return self.model is not None

    def infer(self, frame: np.ndarray, camera_hfov_deg: float = 60.0) -> list[Detection]:
        """Run detection on a single BGR frame. Returns a list of Detection objects."""
        if self.model is None:
            return self._stub_infer(frame, camera_hfov_deg)

        h, w = frame.shape[:2]
        results = self.model.predict(
            frame, conf=config.DETECTION_CONFIDENCE_THRESHOLD, verbose=False
        )[0]

        detections = []
        for box in results.boxes:
            cls_id = int(box.cls[0])
            cls_name = self.model.names.get(cls_id, str(cls_id))
            if cls_name not in self.classes_of_interest:
                continue
            conf = float(box.conf[0])
            x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
            bearing = self._pixel_to_bearing(x1, x2, w, camera_hfov_deg)
            threat = self._threat_level(conf, x1, x2, y1, y2, w, h)
            detections.append(Detection(cls_name, conf, (x1, y1, x2, y2), bearing, threat))
        return detections

    def _stub_infer(self, frame: np.ndarray, camera_hfov_deg: float) -> list[Detection]:
        """
        Fallback used only when ultralytics/weights are unavailable, so the
        rest of the app (streaming, overlay, logging) can still be exercised.
        Detects nothing by default -- replace by installing ultralytics and
        supplying real weights.
        """
        return []

    @staticmethod
    def _pixel_to_bearing(x1: float, x2: float, frame_width: int, hfov_deg: float) -> float:
        """
        Convert a bounding box's horizontal center to a bearing offset
        (degrees, negative = left of UGV heading, positive = right),
        assuming a pinhole camera with the given horizontal field of view.
        """
        cx = (x1 + x2) / 2.0
        normalized = (cx - frame_width / 2.0) / (frame_width / 2.0)  # -1..1
        return normalized * (hfov_deg / 2.0)

    @staticmethod
    def _threat_level(conf: float, x1, x2, y1, y2, frame_w, frame_h) -> str:
        """
        Simple heuristic: larger apparent size (closer object) + higher
        confidence => higher threat. Tune against real-world validation data;
        this is a starting point, not a validated threat model.
        """
        box_area_ratio = ((x2 - x1) * (y2 - y1)) / (frame_w * frame_h)
        score = conf * 0.5 + min(box_area_ratio * 20, 0.5)
        if score > 0.7:
            return "HIGH"
        if score > 0.4:
            return "MEDIUM"
        return "LOW"


def estimate_operator_location(ugv_lat: float, ugv_lon: float, ugv_heading_deg: float,
                                bearing_offset_deg: float, assumed_range_m: float) -> tuple:
    """
    Very rough triangulation: projects a point `assumed_range_m` away from
    the UGV along (heading + bearing_offset). Real direction-finding needs
    either (a) two+ bearings from different UGV/sensor positions triangulated
    together, or (b) an RF direction-finding sensor on the drone's control
    link. This function is a placeholder for a single-bearing "best guess"
    line of bearing -- treat its output as a search sector, not a fix.
    """
    true_bearing = math.radians((ugv_heading_deg + bearing_offset_deg) % 360)
    lat1 = math.radians(ugv_lat)
    lon1 = math.radians(ugv_lon)
    d_over_r = assumed_range_m / config.EARTH_RADIUS_M

    lat2 = math.asin(
        math.sin(lat1) * math.cos(d_over_r) +
        math.cos(lat1) * math.sin(d_over_r) * math.cos(true_bearing)
    )
    lon2 = lon1 + math.atan2(
        math.sin(true_bearing) * math.sin(d_over_r) * math.cos(lat1),
        math.cos(d_over_r) - math.sin(lat1) * math.sin(lat2)
    )
    return math.degrees(lat2), math.degrees(lon2)


def fuse_thermal(visible_frame: np.ndarray, thermal_frame: np.ndarray, alpha: float = 0.5) -> np.ndarray:
    """
    Basic visible/thermal fusion by alpha blending after resizing the
    thermal frame to match the visible frame. For real deployment, replace
    with a proper registered fusion (the two sensors need calibrated
    extrinsics) -- this is a placeholder to unblock software integration
    before the thermal camera hardware is on the bench.
    """
    thermal_resized = cv2.resize(thermal_frame, (visible_frame.shape[1], visible_frame.shape[0]))
    if len(thermal_resized.shape) == 2:
        thermal_resized = cv2.applyColorMap(thermal_resized, cv2.COLORMAP_INFERNO)
    return cv2.addWeighted(visible_frame, 1 - alpha, thermal_resized, alpha, 0)
