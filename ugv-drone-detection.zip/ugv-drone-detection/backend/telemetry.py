"""
Data logging: every detection event is appended to a JSONL telemetry log
and, at a throttled rate, a snapshot frame is saved to disk. Keeping JSONL
(one JSON object per line) makes this trivial to tail, grep, or bulk-load
into pandas later for analysis.
"""
import json
import time
import uuid
from pathlib import Path

import cv2

import config


class TelemetryLogger:
    def __init__(self):
        self._last_image_save = 0.0
        self.min_image_interval_s = 2.0  # throttle disk writes

    def _telemetry_file(self) -> Path:
        day = time.strftime("%Y-%m-%d")
        return config.TELEMETRY_DIR / f"telemetry_{day}.jsonl"

    def log_event(self, event: dict) -> None:
        event["logged_at"] = time.time()
        with open(self._telemetry_file(), "a") as f:
            f.write(json.dumps(event) + "\n")

    def maybe_save_snapshot(self, frame, detections) -> str | None:
        """Save an annotated snapshot if the throttle interval has elapsed
        and there's at least one detection worth recording. Returns the
        saved filename, or None if skipped."""
        now = time.time()
        if not detections or (now - self._last_image_save) < self.min_image_interval_s:
            return None
        self._last_image_save = now
        filename = f"det_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}.jpg"
        path = config.IMAGES_DIR / filename
        cv2.imwrite(str(path), frame, [cv2.IMWRITE_JPEG_QUALITY, config.JPEG_QUALITY])
        return filename

    def read_recent(self, limit: int = 100) -> list[dict]:
        f = self._telemetry_file()
        if not f.exists():
            return []
        lines = f.read_text().strip().splitlines()
        out = [json.loads(line) for line in lines[-limit:]]
        out.reverse()
        return out
