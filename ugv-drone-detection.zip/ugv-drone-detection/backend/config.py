"""
Central configuration for the UGV Drone Detection backend.
Edit these values (or set matching environment variables) before deployment.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
IMAGES_DIR = DATA_DIR / "images"
VIDEOS_DIR = DATA_DIR / "videos"
TELEMETRY_DIR = DATA_DIR / "telemetry"
LOGS_DIR = DATA_DIR / "logs"

for d in (IMAGES_DIR, VIDEOS_DIR, TELEMETRY_DIR, LOGS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# --- Auth ---
# CHANGE THIS before any real deployment. Generate with: openssl rand -hex 32
JWT_SECRET = os.environ.get("UGV_JWT_SECRET", "REPLACE_ME_WITH_A_LONG_RANDOM_SECRET")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_MINUTES = 480  # 8-hour shift token

# Operator accounts. Replace with a real user store (DB + hashed passwords)
# before deployment -- this is a minimal placeholder so the app runs out of the box.
# Passwords below are bcrypt hashes of: "changeme123"
OPERATORS = {
    "operator1": "$2b$12$KIXQwQnQe8b6f2f3M9GdpO7QeXm6nD8gk1Q1cQ2ZlS0S9Z3F1G9Ce",
}

# --- Detection ---
# Path to YOLO weights. Point this at a custom-trained drone-detection model
# (recommended) or a stock COCO model for initial bring-up/demo purposes.
YOLO_WEIGHTS_PATH = os.environ.get("UGV_YOLO_WEIGHTS", str(BASE_DIR / "models" / "drone_yolo.pt"))
DETECTION_CONFIDENCE_THRESHOLD = 0.45
# Stock YOLO/COCO has no "drone" class. Until a custom model is trained,
# these COCO classes are used as visual stand-ins so the pipeline is testable.
DEMO_PROXY_CLASSES = ["airplane", "bird", "kite"]

# --- Camera / stream ---
JPEG_QUALITY = 70
MAX_FRAME_WIDTH = 960  # downscale incoming frames for inference speed

# --- Geo / direction estimation ---
# Placeholder UGV mounting position until a real GPS module is wired in.
DEFAULT_UGV_LAT = 28.6139
DEFAULT_UGV_LON = 77.2090
EARTH_RADIUS_M = 6371000
