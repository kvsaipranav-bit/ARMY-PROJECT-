"""
UGV Drone Detection -- backend entrypoint.

Run with:
    uvicorn app:app --host 0.0.0.0 --port 8000 --reload

Endpoints:
    POST /api/login              -> {token}
    GET  /api/me                 -> current operator (auth check)
    GET  /api/telemetry/recent   -> last N detection/threat events
    WS   /ws/detect               -> live video frame in, detections out
    GET  /                        -> serves frontend/login.html
"""
import base64
import time

import cv2
import numpy as np
from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

import config
from auth import authenticate, get_current_operator
from detection import DroneDetector, estimate_operator_location
from telemetry import TelemetryLogger

app = FastAPI(title="UGV Drone Detection API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to the deployed frontend origin before production use
    allow_methods=["*"],
    allow_headers=["*"],
)

detector = DroneDetector()
telemetry = TelemetryLogger()


# ---------- Auth ----------

class LoginRequest(BaseModel):
    username: str
    password: str


@app.post("/api/login")
def login(req: LoginRequest):
    token = authenticate(req.username, req.password)
    if not token:
        raise HTTPException(401, "Invalid credentials")
    return {"token": token}


@app.get("/api/me")
def me(operator: str = Depends(get_current_operator)):
    return {"operator": operator}


# ---------- Telemetry ----------

@app.get("/api/telemetry/recent")
def recent_telemetry(limit: int = 100, operator: str = Depends(get_current_operator)):
    return telemetry.read_recent(limit)


@app.get("/api/status")
def status():
    return {
        "detector_ready": detector.is_ready,
        "note": None if detector.is_ready else (
            "Running without a loaded YOLO model -- install ultralytics and "
            "place weights at backend/models/drone_yolo.pt (see README)."
        ),
    }


# ---------- Live detection over WebSocket ----------
# Frontend sends: {"frame": "<base64 jpeg>", "ugv_lat":.., "ugv_lon":.., "ugv_heading":..}
# Backend replies: {"detections": [...], "ts": ...}

@app.websocket("/ws/detect")
async def ws_detect(ws: WebSocket, token: str = ""):
    # Basic auth gate: frontend must connect as /ws/detect?token=<jwt from login>
    import jwt as _jwt
    try:
        _jwt.decode(token, config.JWT_SECRET, algorithms=[config.JWT_ALGORITHM])
    except Exception:
        await ws.close(code=4401)
        return
    await ws.accept()
    try:
        while True:
            payload = await ws.receive_json()
            frame = _decode_frame(payload.get("frame", ""))
            if frame is None:
                await ws.send_json({"error": "bad frame"})
                continue

            detections = detector.infer(frame)

            ugv_lat = payload.get("ugv_lat", config.DEFAULT_UGV_LAT)
            ugv_lon = payload.get("ugv_lon", config.DEFAULT_UGV_LON)
            ugv_heading = payload.get("ugv_heading", 0.0)

            out_detections = []
            for d in detections:
                est_lat, est_lon = estimate_operator_location(
                    ugv_lat, ugv_lon, ugv_heading, d.bearing_deg, assumed_range_m=500
                )
                record = {
                    "class_name": d.class_name,
                    "confidence": round(d.confidence, 3),
                    "box": [round(v, 1) for v in d.box],
                    "bearing_deg": round(d.bearing_deg, 1),
                    "threat_level": d.threat_level,
                    "estimated_operator_lat": round(est_lat, 6),
                    "estimated_operator_lon": round(est_lon, 6),
                    "ugv_lat": ugv_lat,
                    "ugv_lon": ugv_lon,
                }
                out_detections.append(record)
                telemetry.log_event(record)

            saved = telemetry.maybe_save_snapshot(frame, detections)

            await ws.send_json({
                "ts": time.time(),
                "detections": out_detections,
                "snapshot_saved": saved,
                "detector_ready": detector.is_ready,
            })
    except WebSocketDisconnect:
        pass


def _decode_frame(b64_jpeg: str):
    if not b64_jpeg:
        return None
    try:
        if "," in b64_jpeg:
            b64_jpeg = b64_jpeg.split(",", 1)[1]
        raw = base64.b64decode(b64_jpeg)
        arr = np.frombuffer(raw, dtype=np.uint8)
        return cv2.imdecode(arr, cv2.IMREAD_COLOR)
    except Exception:
        return None


# ---------- Static frontend ----------

app.mount("/static", StaticFiles(directory="../frontend"), name="static")


@app.get("/")
def root():
    return FileResponse("../frontend/login.html")


@app.get("/dashboard")
def dashboard():
    return FileResponse("../frontend/dashboard.html")
