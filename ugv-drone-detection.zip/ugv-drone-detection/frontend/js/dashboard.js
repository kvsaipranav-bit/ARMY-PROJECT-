const API_BASE = window.location.origin;
const WS_BASE = API_BASE.replace(/^http/, "ws");

const token = sessionStorage.getItem("ugv_token");
if (!token) {
  window.location.href = "/";
}

// ---------- elements ----------
const video = document.getElementById("videoFeed");
const renderCanvas = document.getElementById("videoRender");
const overlay = document.getElementById("overlay");
const startBtn = document.getElementById("startBtn");
const placeholder = document.getElementById("placeholder");
const connDot = document.getElementById("connDot");
const connLabel = document.getElementById("connLabel");
const detectorStatus = document.getElementById("detectorStatus");
const frameCountEl = document.getElementById("frameCount");
const activeTracksEl = document.getElementById("activeTracks");
const threatPanel = document.getElementById("threatPanel");
const logEl = document.getElementById("log");
const needle = document.getElementById("needle");
const bearingVal = document.getElementById("bearingVal");
const hudClock = document.getElementById("hudClock");
const hudGps = document.getElementById("hudGps");
const hudModel = document.getElementById("hudModel");
const operatorLabel = document.getElementById("operatorLabel");
const logoutBtn = document.getElementById("logoutBtn");

let ws = null;
let frameCount = 0;
let sendInterval = null;
let ugvPos = { lat: null, lon: null, heading: 0 };

// ---------- auth check ----------
fetch(`${API_BASE}/api/me`, { headers: { Authorization: `Bearer ${token}` } })
  .then((r) => (r.ok ? r.json() : Promise.reject()))
  .then((d) => (operatorLabel.textContent = `OP: ${d.operator.toUpperCase()}`))
  .catch(() => {
    sessionStorage.removeItem("ugv_token");
    window.location.href = "/";
  });

fetch(`${API_BASE}/api/status`)
  .then((r) => r.json())
  .then((d) => {
    detectorStatus.textContent = d.detector_ready ? "READY (YOLO loaded)" : "STUB (no weights)";
    hudModel.textContent = d.detector_ready ? "MODEL: YOLO-CUSTOM" : "MODEL: NOT LOADED";
  });

logoutBtn.addEventListener("click", () => {
  sessionStorage.removeItem("ugv_token");
  if (ws) ws.close();
  window.location.href = "/";
});

// ---------- UGV / GPS position (placeholder: browser geolocation stands in
// for a real GPS module wired into the UGV until that hardware is on the bench) ----------
if (navigator.geolocation) {
  navigator.geolocation.watchPosition(
    (pos) => {
      ugvPos.lat = pos.coords.latitude;
      ugvPos.lon = pos.coords.longitude;
      ugvPos.heading = pos.coords.heading || 0;
      hudGps.style.display = "block";
      hudGps.textContent = `GPS: ${ugvPos.lat.toFixed(5)}, ${ugvPos.lon.toFixed(5)}`;
    },
    () => { hudGps.textContent = "GPS: UNAVAILABLE"; },
    { enableHighAccuracy: true }
  );
}

// ---------- start live feed ----------
startBtn.addEventListener("click", async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
    video.srcObject = stream;
    await video.play();

    placeholder.style.display = "none";
    overlay.style.display = "block";
    hudClock.style.display = "block";
    hudGps.style.display = "block";
    hudModel.style.display = "block";

    renderCanvas.width = video.videoWidth || 960;
    renderCanvas.height = video.videoHeight || 540;
    overlay.width = renderCanvas.width;
    overlay.height = renderCanvas.height;
    overlay.style.display = "block";
    renderCanvas.style.display = "none"; // hidden capture buffer; overlay drawn on top of <video>
    video.style.display = "block";
    video.style.maxHeight = "calc(100vh - 56px)";
    video.style.maxWidth = "100%";
    overlay.style.width = video.clientWidth + "px";

    connectWebSocket();
    startSendLoop();
    tickClock();
  } catch (err) {
    placeholder.querySelector("div:last-of-type")?.remove();
    const msg = document.createElement("div");
    msg.style.color = "var(--red)";
    msg.style.marginTop = "10px";
    msg.style.fontSize = "12px";
    msg.textContent = "Camera access denied or unavailable: " + err.message;
    placeholder.appendChild(msg);
  }
});

function tickClock() {
  hudClock.textContent = new Date().toISOString().replace("T", " ").slice(0, 19) + "Z";
  requestAnimationFrame(() => setTimeout(tickClock, 1000));
}

// ---------- websocket ----------
function connectWebSocket() {
  ws = new WebSocket(`${WS_BASE}/ws/detect?token=${encodeURIComponent(token)}`);

  ws.onopen = () => {
    connDot.className = "conn-dot live";
    connLabel.textContent = "LIVE";
  };
  ws.onclose = () => {
    connDot.className = "conn-dot down";
    connLabel.textContent = "DISCONNECTED";
  };
  ws.onerror = () => {
    connDot.className = "conn-dot down";
    connLabel.textContent = "ERROR";
  };
  ws.onmessage = (evt) => {
    const data = JSON.parse(evt.data);
    if (data.error) return;
    renderDetections(data.detections || []);
    detectorStatus.textContent = data.detector_ready ? "READY (YOLO loaded)" : "STUB (no weights)";
  };
}

// ---------- send frames periodically ----------
function startSendLoop() {
  const ctx = renderCanvas.getContext("2d");
  sendInterval = setInterval(() => {
    if (!ws || ws.readyState !== WebSocket.OPEN || video.readyState < 2) return;
    ctx.drawImage(video, 0, 0, renderCanvas.width, renderCanvas.height);
    const jpeg = renderCanvas.toDataURL("image/jpeg", 0.7);
    ws.send(JSON.stringify({
      frame: jpeg,
      ugv_lat: ugvPos.lat,
      ugv_lon: ugvPos.lon,
      ugv_heading: ugvPos.heading,
    }));
    frameCount += 1;
    frameCountEl.textContent = frameCount;
  }, 500); // 2 fps -- raise for higher-power hardware, lower for constrained links
}

// ---------- render detections: overlay boxes + side panels ----------
function renderDetections(detections) {
  const ctx = overlay.getContext("2d");
  ctx.clearRect(0, 0, overlay.width, overlay.height);

  activeTracksEl.textContent = detections.length;

  if (detections.length === 0) {
    threatPanel.innerHTML = '<div class="threat-empty">No contacts detected</div>';
    needle.style.transform = "translate(-50%, -100%) rotate(0deg)";
    bearingVal.textContent = "—";
    return;
  }

  let panelHtml = "";
  detections.forEach((d) => {
    const [x1, y1, x2, y2] = d.box;
    const color = d.threat_level === "HIGH" ? "#ff3b3b" : d.threat_level === "MEDIUM" ? "#ffb020" : "#3dff8a";
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
    ctx.font = "12px IBM Plex Mono";
    ctx.fillStyle = color;
    ctx.fillText(`${d.class_name.toUpperCase()} ${(d.confidence * 100).toFixed(0)}%`, x1, y1 - 6);

    panelHtml += `
      <div class="threat-card">
        <div class="top-row">
          <span class="cls">${d.class_name.toUpperCase()}</span>
          <span class="lvl threat-${d.threat_level}">${d.threat_level}</span>
        </div>
        <div class="stat-row"><span class="k">Confidence</span><span class="v">${(d.confidence * 100).toFixed(0)}%</span></div>
        <div class="stat-row"><span class="k">Bearing</span><span class="v">${d.bearing_deg}°</span></div>
        <div class="stat-row"><span class="k">Est. operator</span><span class="v">${d.estimated_operator_lat}, ${d.estimated_operator_lon}</span></div>
      </div>`;

    appendLog(d);
  });
  threatPanel.innerHTML = panelHtml;

  const primary = detections[0];
  needle.style.transform = `translate(-50%, -100%) rotate(${primary.bearing_deg}deg)`;
  bearingVal.textContent = `${primary.bearing_deg}°`;
}

function appendLog(d) {
  const row = document.createElement("div");
  row.className = "log-row";
  const t = new Date().toLocaleTimeString();
  row.innerHTML = `[${t}] <span class="lvl-${d.threat_level}">${d.threat_level}</span> ${d.class_name} conf=${(d.confidence * 100).toFixed(0)}% brg=${d.bearing_deg}°`;
  logEl.prepend(row);
  while (logEl.children.length > 200) logEl.removeChild(logEl.lastChild);
}
