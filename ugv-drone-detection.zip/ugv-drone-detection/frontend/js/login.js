const API_BASE = window.location.origin; // backend + frontend served from same FastAPI app

const form = document.getElementById("loginForm");
const statusLine = document.getElementById("statusLine");
const loginBtn = document.getElementById("loginBtn");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  statusLine.textContent = "Authenticating...";
  statusLine.className = "status-line";
  loginBtn.disabled = true;

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;

  try {
    const res = await fetch(`${API_BASE}/api/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || "Invalid credentials");
    }

    const data = await res.json();
    sessionStorage.setItem("ugv_token", data.token);
    statusLine.textContent = "Access granted. Loading console...";
    statusLine.className = "status-line ok";
    window.location.href = "/dashboard";
  } catch (err) {
    statusLine.textContent = err.message || "Login failed";
    statusLine.className = "status-line err";
    loginBtn.disabled = false;
  }
});
